package com.devsuperior.uri2990.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.devsuperior.uri2990.entities.Empregado;

public interface EmpregadoRepository extends JpaRepository<Empregado, Long> {

}
