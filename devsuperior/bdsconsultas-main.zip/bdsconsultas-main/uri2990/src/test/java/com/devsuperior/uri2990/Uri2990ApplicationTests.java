package com.devsuperior.uri2990;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Uri2990ApplicationTests {

	@Test
	void contextLoads() {
	}

}
