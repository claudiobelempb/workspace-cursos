package com.devsuperior.uri2611;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Uri2611ApplicationTests {

	@Test
	void contextLoads() {
	}

}
